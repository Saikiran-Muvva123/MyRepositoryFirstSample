package com.src.Bank.BankExample.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Entity
@Table(name = "student")
@JsonIgnoreProperties({ "hibernateLazyInitializer", "handler" })
public class Bank {

	@Id
	Integer Bankid;
	String Bankname;

	public Integer getId() {
		return Bankid;
	}

	public void setId(Integer id) {
		this.Bankid = Bankid;
	}

	public String getName() {
		return Bankname;
	}

	public void setName(String name) {
		this.Bankname = Bankname;
	}

}
